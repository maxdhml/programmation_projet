from random import randint

def liste_utilisateur(n=5):

    l = []
    for i in range(n):
        nb = int(input(f"Nombre {i + 1} : "))
        l.append(nb)
    return l

def liste_aleatoire(n=5, bornemin=0, bornemax=100):

    l = []
    for _ in range(n):
        l.append(randint(bornemin, bornemax))
    return l


l1 = liste_utilisateur(4)
print(l1)  
l2 = liste_aleatoire(4)
print(l2)
