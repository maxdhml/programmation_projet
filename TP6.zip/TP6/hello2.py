def hello(nom = "inconnu(e)"):  
    return (f"Hello {nom} !")

print (hello ())