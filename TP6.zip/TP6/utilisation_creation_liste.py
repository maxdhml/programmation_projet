from creation_liste import liste_aleatoire

print(liste_aleatoire(5,1,20))