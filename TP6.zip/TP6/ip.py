from random import randint

def adresses_ip(classe="A") -> str:
    
    if classe == "A":
        premier_min, premier_max = 0, 127
    elif classe == "B":
        premier_min, premier_max = 128, 191
    elif classe == "C":
        premier_min, premier_max = 192, 223
    elif classe == "D":
        premier_min, premier_max = 224, 239
    elif classe == "E":
        premier_min, premier_max = 240, 255
    else:
        premier_min, premier_max = 0, 255  
        
    premier = randint(premier_min, premier_max)
    octet2 = randint(0, 255)
    octet3 = randint(0, 255)
    octet4 = randint(0, 255)

    return f"{premier}.{octet2}.{octet3}.{octet4}"


def classe(adresse: str) -> str:
    premier = int(adresse.split('.')[0])

    if 0 <= premier <= 127:
        return "A"
    elif 128 <= premier <= 191:
        return "B"
    elif 192 <= premier <= 223:
        return "C"
    elif 224 <= premier <= 239:
        return "D"
    elif 240 <= premier <= 255:
        return "E"
    else:
        return "Inconnue"


if __name__ == "__main__":
    adr = adresses_ip("A")
    print(f"{adr} est de classe {classe(adr)}")
