from math import pi

rayon = float(input("Rayon (cm) ? "))
perimetre = 2 * pi * rayon
aire = pi * rayon ** 2
print(f"Périmètre = {perimetre:.2f} cm")
print(f"Aire = {aire:.2f} cm²")