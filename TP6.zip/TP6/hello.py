def hello(nom):  
    return (f"Hello {nom} !")

print (hello ("Maxime"))