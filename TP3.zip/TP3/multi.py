n = int(input ("n ? "))
for i in range (10) :
    print (f"{n} x {i} = {n * i}")