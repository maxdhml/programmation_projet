h = int(input("h ? "))

for i in range(1, h + 1):

    espaces = " " * (h - i)

    etoiles = "*" * (2 * i - 1)
    
    print(espaces + etoiles)
