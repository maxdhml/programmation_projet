mot = input("Mot ? ")
print("Répétitions : ", end="") 
for _ in range(3):
    print(mot, end=" ")
print()  