n = int(input("n ? "))

if n > 20:
    print("Il faut rentrer un nombre plus petit que 20.")
else:
    
    countdown = list(range(20, n-1, -1))
  
    print(", ".join(str(x) for x in countdown))
