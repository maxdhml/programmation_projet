compt_sens = input("Voulez-vous compter vers le haut (h) ou vers le bas (b) ? (h/b) ")
n = int(input("n ? "))

if compt_sens == 'b':
    if n < 50:
        countdown = list(range(50, n - 1, -1))
        print(", ".join(str(x) for x in countdown))
    else:
        print("Le nombre doit être strictement inférieur à 50.")
elif compt_sens == 'h':
    if n < 50:
        countdown = list(range(1, n + 1))
        print(", ".join(str(x) for x in countdown))
    else:
        print("Le nombre doit être strictement inférieur à 50.")
else:
    print("Je ne comprends pas votre choix.")
