nom = input ("Nom ? ")
for lettre in nom : 
    print (lettre)