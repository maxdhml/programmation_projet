nb_7 = 0
for i in range(1, 101):
    str_i = str(i)
    for caractere in str_i:
        if caractere == '7':
            nb_7 += 1
print(f"Combien de 7 rencontrez-vous en comptant de 1 à 100 ? {nb_7}")
