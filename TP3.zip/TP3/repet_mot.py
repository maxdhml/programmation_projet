mot = input ("Mot ? ")
rep = int(input ("Nombre de répétitons ? "))
print (f"Voici vos {rep} répétition(s): ", end= "")
for i in range (rep) :
    print (mot, end= " ")
print ()