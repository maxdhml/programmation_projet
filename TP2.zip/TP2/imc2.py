poids = float(input ("Veuillez svp entrer votre poids en kg : "))

taille = float(input ("Veuillez svp entrer votre taille en m :"))

imc = poids/taille ** 2

if imc < 18.5 :
    print (f"Votre IMC est de {round (imc, 2)}. Vous êtes dans une situation de maigreur.")
elif 18.5 <= imc < 25 :
    print (f"Votre IMC est de {round (imc, 2)}. Vous êtes dans une situation de poids normal.")
elif 25 <= imc < 30 :
    print (f"Votre IMC est de {round (imc, 2)}. Vous êtes dans une situation de surpoids.")
elif 30 <= imc : 
    print (f"Votre IMC est de {round (imc, 2)}. Vous êtes dans une situation de obésité.")
