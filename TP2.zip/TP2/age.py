nom = input ("Votre nom : ")
age = int(input ("Votre age : "))
nouvelage = age + 1

print (f"{nom}, à votre prochain anniversaire, vous aurez {nouvelage} ans.")
