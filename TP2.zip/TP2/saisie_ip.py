adresse = input("Veuillez svp entrer une adresse ipv4 : ")
ipv4 = adresse.split(".")

if (len(ipv4) == 4
    and ipv4[0].isdigit()
    and ipv4[1].isdigit()
    and ipv4[2].isdigit()
    and ipv4[3].isdigit()
    and int(ipv4[0]) >= 0 and int(ipv4[0]) <= 255
    and int(ipv4[1]) >= 0 and int(ipv4[1]) <= 255
    and int(ipv4[2]) >= 0 and int(ipv4[2]) <= 255
    and int(ipv4[3]) >= 0 and int(ipv4[3]) <= 255
   ):
    print(f"{adresse} est une adresse IPv4 valide.")
else:
    print(f"{adresse} n'est pas une adresse IPv4 valide.")
