nom = input ("Votre nom : ")
prenom = input ("Votre prénom : ")

print (f"Salut {prenom} {nom}, comment ça va ?")