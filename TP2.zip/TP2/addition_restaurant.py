addition = float(input ("Quelle est le montant total de l'addition ? "))
convives = float(input ("Quel est le nombre de convives ? "))
montant = addition/convives 

print (f"Le montant par personne est de {montant} euro(s).")