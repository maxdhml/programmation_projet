nb1 = int(input ("Nombre 1 : "))
nb2 = int(input ("Nombre 2 : "))
nb3 = int(input ("Nombre 3 : "))
resultat1 = nb1 + nb2
resultatfinal = resultat1 * nb3
print (f"Le résultat est {resultatfinal}")