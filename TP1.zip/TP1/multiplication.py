n1 = int(input ("n1 = "))
n2 = int(input ("n2 = "))

print (f"Le produit de {n1} + {n2} vaut {n1 * n2}.")