age = int(input("Quel est votre âge ? "))

if age > 64:
    print("Vous avez droit de prendre votre retraite.")
elif age > 18:
    print("Vous pouvez voter.")
elif age > 16:
    print("Vous pouvez apprendre à conduire.")
elif age > 14:
    print("Vous pouvez avoir une trottinette électrique.")
else:
    print("Vous pouvez jouer au marché de Padi Pado.")
