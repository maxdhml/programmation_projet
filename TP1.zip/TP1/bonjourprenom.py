prenom = input ("Comment t'appelles-tu ? ")
print ("Bonjour", prenom , "!")
