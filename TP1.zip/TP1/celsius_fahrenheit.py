conversion = input("Tapez 'C' pour convertir Celsius en Fahrenheit, ou 'F' pour convertir Fahrenheit en Celsius : ").strip().upper()

if conversion == 'C':
    degres_celsius = float(input("Entrez la température en degrés Celsius : "))
    degres_fahrenheit = degres_celsius * 1.8 + 32
    print(f"{degres_celsius}°C = {degres_fahrenheit:.2f}°F")
elif conversion == 'F':
    degres_fahrenheit = float(input("Entrez la température en degrés Fahrenheit : "))
    degres_celsius = (degres_fahrenheit - 32) / 1.8
    print(f"{degres_fahrenheit}°F = {degres_celsius:.2f}°C")
else:
    print("Choix invalide, veuillez taper 'C' ou 'F'.")
