Nomb1 = float(input ("Nombre 1 : "))

Nomb2 = float(input ("Nombre 2 : "))

if Nomb1 < Nomb2 : 
    print ("Le maximum est" , Nomb2 )
else :
    print ("Le maximum est", Nomb1)

    