jours = int(input("Nombre de jours : "))
print (f"{jours} jour(s) correspondent à {jours * 24} heure(s) ou {jours * 1440} minute(s) ou {jours * 86400} seconde(s)")