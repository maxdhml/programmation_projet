mot = input ("Mot : ")
mot = mot.lower()

if mot == mot [::-1] :
    print ( mot , "est un palindrome")
else :
    print ( mot , "n'est pas un palindrome")
