liste = []

liste.append(input("Nom de votre machine : "))
liste.append(int(input("RAM (Go) : ")))
liste.append(float(input("CPU (GHz) : ")))

print(f"La liste contient : {liste[::]}")
