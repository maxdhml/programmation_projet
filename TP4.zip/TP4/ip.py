ipv4 = input ("Adresse IP ? ")
liste = ipv4.split('.')
octet = int(liste[0])
if 0 < octet < 127 :
    print (f"L'adresse {ipv4} est de classe A.")
elif 128 < octet < 191 :
    print (f"L'adresse {ipv4} est de classe B.")
elif 192 < octet < 223 :
    print (f"L'adresse {ipv4} est de classe C.")
elif 224 < octet < 239 :
    print (f"L'adresse {ipv4} est de classe D.")
else :
    print (f"L'adresse {ipv4} est de classe E.")