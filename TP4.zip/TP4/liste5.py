n = int(input("Nombre d'entiers ? "))

l = []

for i in range(n):
    valeur = int(input(f"l[{i}] = "))
    l.append(valeur)

print(f"Liste créée : {l}")
