liste2 =[]
for i in range (1, 1001) :
    liste2.append(i)
print (liste2)
