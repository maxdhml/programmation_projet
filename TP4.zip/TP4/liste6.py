l = [2, 3, 5, 7]

print(l)

choix = input("Souhaitez-vous ajouter (a) ou supprimer (s) un entier ? (a/s) ").lower()

if choix == 'a':
    indice = int(input("À quel indice ? "))
    nombre = int(input("Quel nombre entier ? "))
    l.insert(indice, nombre)
elif choix == 's':
    indice = int(input("À quel indice ? "))
    if 0 <= indice < len(l):
        l.pop(indice)
    else:
        print("Indice invalide, suppression impossible.")
else:
    print("Choix invalide.")

print(l)
