liste = [1, 4, 5, 67, 23.2, -12, 0]
print (f"Premier élément =  {liste[0]}")
print (f"Dernier élément =  {liste[-1]}")
print (f"3 premiers éléments =  {liste[0:3]}")
print (f"3 derniers éléments =  {liste[-3:]}")
print (f"Nombre d'éléments =  {len(liste)}")
print (f"Min =  {min(liste)}")
print (f"Max =  {max(liste)}")
print (f"Somme =  {sum(liste)}")
print (f"Liste ordonnée de manière croissante =  {(sorted(liste))}")
print (f"Liste ordonnée de manière décroissante =  {sorted(liste, reverse=True)}")

