liste = [None, None, None]  

liste[0] = input("Nom de votre machine : ")
liste[1] = int(input("RAM (Go) : "))
liste[2] = float(input("CPU (GHz) : "))

print(f"La liste contient : {liste[::]}")
